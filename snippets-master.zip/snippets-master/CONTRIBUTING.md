# Contributing

The goal of this repository is to manage our snippets for internal use, so unless you'd come across a typo or another minor error, we won't be accepting pull requests.
